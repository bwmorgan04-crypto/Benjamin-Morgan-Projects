import json
import urllib.request


class ClaudeClient:
    """
    Minimal Anthropic Messages API client.

    IMPORTANT:
    - This expects Claude to return STRICT JSON only in the response text.
    - You must set environment variable ANTHROPIC_API_KEY on Windows, then restart Fusion.
    """

    def __init__(self, api_key: str, model: str = "claude-3-5-sonnet-latest"):
        self.api_key = api_key
        self.model = model

    def generate_params(self, prompt: str) -> dict:
        url = "https://api.anthropic.com/v1/messages"
        payload = {
            "model": self.model,
            "max_tokens": 2048,
            "temperature": 0,
            "system": (
                "You are a CAD parameter generator. "
                "Return ONLY valid JSON that matches the required schema. "
                "No markdown, no commentary, no backticks."
            ),
            "messages": [{"role": "user", "content": prompt}],
        }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("x-api-key", self.api_key)
        req.add_header("anthropic-version", "2023-06-01")

        with urllib.request.urlopen(req, timeout=60) as resp:
            raw = resp.read().decode("utf-8")

        wrapper = json.loads(raw)

        # Typical Messages API shape: content is an array of content blocks
        content_text = ""
        blocks = wrapper.get("content", [])
        if blocks and isinstance(blocks, list):
            content_text = blocks[0].get("text", "") or ""

        try:
            return json.loads(content_text)
        except Exception as e:
            raise ValueError(
                "Claude did not return valid JSON.\n\n"
                f"Raw text:\n{content_text}\n\nError: {e}"
            )