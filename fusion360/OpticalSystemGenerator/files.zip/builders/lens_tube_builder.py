import adsk.core
import adsk.fusion


class LensTubeBuilder:
    def __init__(self, app, design, pm):
        self.app = app
        self.design = design
        self.pm = pm

    def build(self, root_comp: adsk.fusion.Component):
        occ = root_comp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = occ.component
        comp.name = "LensTubeHousing"

        sketches = comp.sketches
        extrudes = comp.features.extrudeFeatures

        # Base (square) on XY
        sk_base = sketches.add(comp.xYConstructionPlane)
        base_size = self.design.userParameters.itemByName("base_size").value
        lines = sk_base.sketchCurves.sketchLines
        lines.addTwoPointRectangle(
            adsk.core.Point3D.create(-base_size / 2, -base_size / 2, 0),
            adsk.core.Point3D.create(base_size / 2, base_size / 2, 0),
        )

        base_prof = sk_base.profiles.item(0)
        base_in = extrudes.createInput(base_prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        base_in.setDistanceExtent(False, adsk.core.ValueInput.createByString("base_thickness"))
        base_ext = extrudes.add(base_in)
        base_body = base_ext.bodies.item(0)
        base_body.name = "LensTubeBase"

        # Tube sketch on top of base
        top_face = base_ext.endFaces.item(0)
        sk_tube = sketches.add(top_face)
        circles = sk_tube.sketchCurves.sketchCircles
        circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), self.design.userParameters.itemByName("outer_radius").value)

        tube_prof = sk_tube.profiles.item(0)
        tube_in = extrudes.createInput(tube_prof, adsk.fusion.FeatureOperations.JoinFeatureOperation)
        tube_in.setDistanceExtent(False, adsk.core.ValueInput.createByString("tube_height"))
        tube_ext = extrudes.add(tube_in)

        # Shell tube (remove top face)
        shell_feats = comp.features.shellFeatures
        shell_in = shell_feats.createInput(adsk.core.ObjectCollection.create(), True)
        shell_in.facesToRemove.add(tube_ext.endFaces.item(0))
        shell_in.insideThickness = adsk.core.ValueInput.createByString("shell_thickness")
        shell_feats.add(shell_in)

        # Cutout in base aligned to optical axis (with optional XY offsets)
        bottom_face = base_ext.startFaces.item(0)
        sk_cut = sketches.add(bottom_face)
        cut_circles = sk_cut.sketchCurves.sketchCircles

        cx = self.design.userParameters.itemByName("cutout_offset_x").value
        cy = self.design.userParameters.itemByName("cutout_offset_y").value
        cut_d = self.design.userParameters.itemByName("cutout_diameter").value
        cut_circles.addByCenterRadius(adsk.core.Point3D.create(cx, cy, 0), cut_d / 2)

        cut_prof = sk_cut.profiles.item(0)
        cut_in = extrudes.createInput(cut_prof, adsk.fusion.FeatureOperations.CutFeatureOperation)
        cut_in.setDistanceExtent(False, adsk.core.ValueInput.createByString("base_thickness"))
        extrudes.add(cut_in)

        # Lip: ring on a plane offset from the top face
        planes = comp.constructionPlanes
        plane_in = planes.createInput()
        plane_in.setByOffset(top_face, adsk.core.ValueInput.createByString("lip_offset_from_sensor"))
        lip_plane = planes.add(plane_in)

        sk_lip = sketches.add(lip_plane)
        lip_circles = sk_lip.sketchCurves.sketchCircles
        lip_circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), self.design.userParameters.itemByName("lip_outer_r").value)
        lip_circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), self.design.userParameters.itemByName("lip_inner_r").value)

        # Select annulus profile (2 loops)
        lip_prof = None
        for i in range(sk_lip.profiles.count):
            p = sk_lip.profiles.item(i)
            if p.profileLoops.count == 2:
                lip_prof = p
                break
        if lip_prof is None:
            lip_prof = sk_lip.profiles.item(0)

        lip_in = extrudes.createInput(lip_prof, adsk.fusion.FeatureOperations.JoinFeatureOperation)
        lip_in.setDistanceExtent(False, adsk.core.ValueInput.createByString("lip_height"))
        extrudes.add(lip_in)

        return occ