import adsk.core
import adsk.fusion


class SensorBuilder:
    """
    Creates a physical sensor body as a parametric reference.

    NOTE:
    For maximum parametric robustness, a plane-offset approach is ideal.
    This starter version places the sensor component occurrence using a transform.
    """

    def __init__(self, app: adsk.core.Application, design: adsk.fusion.Design, pm):
        self.app = app
        self.design = design
        self.pm = pm

    def build(self, root_comp: adsk.fusion.Component) -> adsk.fusion.Occurrence:
        sensor_occ = root_comp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = sensor_occ.component
        comp.name = "Sensor"

        sketches = comp.sketches
        sk = sketches.add(comp.xYConstructionPlane)

        w = self.design.userParameters.itemByName("sensor_w").value
        h = self.design.userParameters.itemByName("sensor_h").value

        lines = sk.sketchCurves.sketchLines
        lines.addTwoPointRectangle(
            adsk.core.Point3D.create(-w / 2, -h / 2, 0),
            adsk.core.Point3D.create(w / 2, h / 2, 0),
        )

        prof = sk.profiles.item(0)
        extrudes = comp.features.extrudeFeatures

        ext_in = extrudes.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        ext_in.setDistanceExtent(False, adsk.core.ValueInput.createByString("sensor_d"))
        ext = extrudes.add(ext_in)
        ext.bodies.item(0).name = "SensorBody"

        # Place sensor at Z = sensor_offset_z
        z = self.design.userParameters.itemByName("sensor_offset_z").value
        m = adsk.core.Matrix3D.create()
        m.translation = adsk.core.Vector3D.create(0, 0, z)
        sensor_occ.transform = m

        return sensor_occ