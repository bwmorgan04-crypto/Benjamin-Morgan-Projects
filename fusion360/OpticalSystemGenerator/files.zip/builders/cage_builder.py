import adsk.core
import adsk.fusion


class CageBuilder:
    def __init__(self, app, design, pm):
        self.app = app
        self.design = design
        self.pm = pm

    def build(self, root_comp: adsk.fusion.Component):
        occ = root_comp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        comp = occ.component
        comp.name = "CageSystem"

        planes = comp.constructionPlanes
        base_xy = comp.xYConstructionPlane

        def offset_plane(expr: str):
            pi = planes.createInput()
            pi.setByOffset(base_xy, adsk.core.ValueInput.createByString(expr))
            return planes.add(pi)

        sensor_plane = base_xy
        diffuser_plane = offset_plane("sensor_to_diffuser")
        lens_plane = offset_plane("sensor_to_diffuser + diffuser_to_lens")

        self._build_plate(comp, sensor_plane, "SensorPlate", "cutout_diameter")
        self._build_plate(comp, diffuser_plane, "DiffuserPlate", "diffuser_diameter")
        self._build_plate(comp, lens_plane, "LensPlate", "lens_diameter")

        self._build_rods(comp)
        return occ

    def _build_plate(self, comp: adsk.fusion.Component, plane, name: str, center_hole_param: str):
        sketches = comp.sketches
        sk = sketches.add(plane)

        plate_size = self.design.userParameters.itemByName("plate_size").value
        lines = sk.sketchCurves.sketchLines
        lines.addTwoPointRectangle(
            adsk.core.Point3D.create(-plate_size / 2, -plate_size / 2, 0),
            adsk.core.Point3D.create(plate_size / 2, plate_size / 2, 0),
        )

        circles = sk.sketchCurves.sketchCircles

        center_d = self.design.userParameters.itemByName(center_hole_param).value
        circles.addByCenterRadius(adsk.core.Point3D.create(0, 0, 0), center_d / 2)

        rs = self.design.userParameters.itemByName("rod_spacing").value
        mount_d = self.design.userParameters.itemByName("mount_hole_diameter").value
        for sx in (-1, 1):
            for sy in (-1, 1):
                circles.addByCenterRadius(adsk.core.Point3D.create(sx * rs / 2, sy * rs / 2, 0), mount_d / 2)

        extrudes = comp.features.extrudeFeatures
        prof = self._largest_profile(sk)

        ext_in = extrudes.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        ext_in.setDistanceExtent(False, adsk.core.ValueInput.createByString("plate_thickness"))
        ext = extrudes.add(ext_in)
        body = ext.bodies.item(0)
        body.name = name
        return body

    def _build_rods(self, comp: adsk.fusion.Component):
        sketches = comp.sketches
        sk = sketches.add(comp.xYConstructionPlane)
        circles = sk.sketchCurves.sketchCircles

        rs = self.design.userParameters.itemByName("rod_spacing").value
        rod_r = self.design.userParameters.itemByName("rod_diameter").value / 2

        for sx in (-1, 1):
            for sy in (-1, 1):
                circles.addByCenterRadius(adsk.core.Point3D.create(sx * rs / 2, sy * rs / 2, 0), rod_r)

        length_expr = "sensor_to_diffuser + diffuser_to_lens + plate_thickness"
        extrudes = comp.features.extrudeFeatures

        for i in range(sk.profiles.count):
            prof = sk.profiles.item(i)
            ext_in = extrudes.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            ext_in.setDistanceExtent(False, adsk.core.ValueInput.createByString(length_expr))
            ext = extrudes.add(ext_in)
            ext.bodies.item(0).name = f"Rod_{i+1}"

    def _largest_profile(self, sk: adsk.fusion.Sketch):
        best = sk.profiles.item(0)
        best_area = -1
        for i in range(sk.profiles.count):
            p = sk.profiles.item(i)
            try:
                area = p.areaProperties().area
                if area > best_area:
                    best_area = area
                    best = p
            except:
                pass
        return best