# OpticalSystemGenerator (Fusion 360 Add-In)

Generates a parametric optical stack:
- Sensor body (physical reference)
- Lens tube housing (base + shelled tube + cutout + lip)
- Cage system (3 plates + 4 rods)

## Install (Windows)

1. Clone or download this repo.
2. Copy the folder `fusion360/OpticalSystemGenerator` into:

`C:\Users\<YOU>\AppData\Roaming\Autodesk\Autodesk Fusion 360\API\AddIns\OpticalSystemGenerator`

3. In Fusion 360:
   - Utilities → Scripts and Add-Ins → Add-Ins
   - Select **OpticalSystemGenerator**
   - Click **Run**
   - (Optional) enable **Run on Startup**

## Claude API (optional)

Set an environment variable:

- Name: `ANTHROPIC_API_KEY`
- Value: your API key

Restart Fusion 360 after setting it.

In `OpticalSystemGenerator.py`, set `use_claude = True`.

## Notes

This is a starter add-in. The geometry is parametric via named parameters.
For maximum robustness, the sensor offset should be implemented using offset construction planes instead of occurrence transforms.