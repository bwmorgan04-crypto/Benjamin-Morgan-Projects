import adsk.core
import adsk.fusion


class ParameterManager:
    def __init__(self, design: adsk.fusion.Design, units: str = "mm"):
        self.design = design
        self.units = units

    def upsert(self, name: str, expression: str, comment: str = ""):
        up = self.design.userParameters.itemByName(name)
        if up:
            up.expression = expression
            if comment:
                up.comment = comment
            return up

        val = adsk.core.ValueInput.createByString(expression)
        return self.design.userParameters.add(name, val, self.units, comment)