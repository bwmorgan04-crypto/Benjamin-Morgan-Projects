def require(d, path: str):
    cur = d
    for p in path.split("."):
        if p not in cur:
            raise ValueError(f"Missing required parameter: {path}")
        cur = cur[p]
    return cur


def with_default(d, path: str, default):
    cur = d
    parts = path.split(".")
    for p in parts[:-1]:
        cur = cur.setdefault(p, {})
    return cur.setdefault(parts[-1], default)


def validate_and_fill(params: dict) -> dict:
    require(params, "component")

    required = [
        "lens_tube.inner_radius",
        "lens_tube.outer_radius",
        "lens_tube.tube_height",
        "lens_tube.lip_offset_from_sensor",
        "cage_system.rod_spacing",
        "cage_system.plate_distances.sensor_to_diffuser",
        "cage_system.plate_distances.diffuser_to_lens",
        "cage_system.sensor_object.width",
        "cage_system.sensor_object.height",
        "cage_system.sensor_object.offset_from_base",
        "cage_system.diffuser_diameter",
        "cage_system.lens_diameter",
    ]
    for p in required:
        require(params, p)

    # Lens tube defaults
    with_default(params, "lens_tube.base_size", 50)
    with_default(params, "lens_tube.base_thickness", 6)
    with_default(params, "lens_tube.shell_thickness", 2)
    with_default(params, "lens_tube.cutout_diameter", 20)
    with_default(params, "lens_tube.cutout_offset_x", 0)
    with_default(params, "lens_tube.cutout_offset_y", 0)
    with_default(params, "lens_tube.lip_height", 2)
    with_default(params, "lens_tube.lip_thickness", 2)
    with_default(params, "lens_tube.clearance", 0.2)

    # Cage system defaults
    with_default(params, "cage_system.plate_thickness", 4)
    with_default(params, "cage_system.plate_size", 80)
    with_default(params, "cage_system.rod_diameter", 6)
    with_default(params, "cage_system.mount_hole_diameter", 3.2)
    with_default(params, "cage_system.sensor_object.depth", 2)

    # Sanity checks
    lt = params["lens_tube"]
    if lt["inner_radius"] <= 0:
        raise ValueError("lens_tube.inner_radius must be > 0")
    if lt["outer_radius"] <= lt["inner_radius"]:
        raise ValueError("lens_tube.outer_radius must be > lens_tube.inner_radius")
    if lt["shell_thickness"] <= 0:
        raise ValueError("lens_tube.shell_thickness must be > 0")
    if lt["tube_height"] <= 0:
        raise ValueError("lens_tube.tube_height must be > 0")

    cs = params["cage_system"]
    if cs["rod_spacing"] <= 0:
        raise ValueError("cage_system.rod_spacing must be > 0")

    return params