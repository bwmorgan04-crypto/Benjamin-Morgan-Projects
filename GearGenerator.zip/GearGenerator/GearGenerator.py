"""Fusion 360 Gear Generator v2.0
Draws complete gear profiles directly in sketch - no circular patterns needed.
All teeth are generated mathematically for maximum reliability.
Author: Benjamin Morgan
"""

import math
import traceback
import adsk.core # type: ignore
import adsk.fusion # type: ignore

app = adsk.core.Application.get()
ui = app.userInterface


# -- Gear Profile Generators -------------------------------------------------

def spur_gear_outline(num_teeth, module_cm):
    """Generate complete external gear outline as list of (x, y) points in cm.
    Draws ALL teeth in one closed polygon. No circular pattern needed.
    """
    pitch_r = num_teeth * module_cm / 2.0
    tip_r = pitch_r + module_cm               # Addendum = 1 module
    root_r = pitch_r - 1.25 * module_cm       # Dedendum = 1.25 module

    if root_r <= 0:
        raise ValueError("Root radius is zero or negative. Increase teeth count or module.")

    ang = 2.0 * math.pi / num_teeth          # Angular pitch per tooth
    tooth_half = ang * 0.25                    # Half-width of tooth at root
    tip_half = ang * 0.15                      # Half-width of tooth at tip

    pts = []
    for i in range(num_teeth):
        c = i * ang                            # Center angle of this tooth

        # Root arc (gap between teeth) - 2 points
        pts.append((root_r * math.cos(c - ang / 2.0),
                     root_r * math.sin(c - ang / 2.0)))
        mid = c - ang / 2.0 + (ang / 2.0 - tooth_half) * 0.5
        pts.append((root_r * math.cos(mid), root_r * math.sin(mid)))

        # Left flank: root to tip
        pts.append((root_r * math.cos(c - tooth_half),
                     root_r * math.sin(c - tooth_half)))
        pts.append((tip_r * math.cos(c - tip_half),
                     tip_r * math.sin(c - tip_half)))

        # Tip arc - 3 points
        pts.append((tip_r * math.cos(c), tip_r * math.sin(c)))

        # Right flank: tip to root
        pts.append((tip_r * math.cos(c + tip_half),
                     tip_r * math.sin(c + tip_half)))
        pts.append((root_r * math.cos(c + tooth_half),
                     root_r * math.sin(c + tooth_half)))

    return pts


def ring_gear_outline(num_teeth, module_cm):
    """Generate internal ring gear inner tooth boundary.
    Teeth point inward. Returns (inner_pts, outer_radius).
    """
    pitch_r = num_teeth * module_cm / 2.0
    root_r = pitch_r + 1.25 * module_cm       # Root is farther from center
    tip_r = pitch_r - module_cm                # Tips point inward

    ang = 2.0 * math.pi / num_teeth
    tooth_half = ang * 0.25
    tip_half = ang * 0.15

    pts = []
    for i in range(num_teeth):
        c = i * ang

        pts.append((root_r * math.cos(c - ang / 2.0),
                     root_r * math.sin(c - ang / 2.0)))
        mid = c - ang / 2.0 + (ang / 2.0 - tooth_half) * 0.5
        pts.append((root_r * math.cos(mid), root_r * math.sin(mid)))

        pts.append((root_r * math.cos(c - tooth_half),
                     root_r * math.sin(c - tooth_half)))
        pts.append((tip_r * math.cos(c - tip_half),
                     tip_r * math.sin(c - tip_half)))

        pts.append((tip_r * math.cos(c), tip_r * math.sin(c)))

        pts.append((tip_r * math.cos(c + tip_half),
                     tip_r * math.sin(c + tip_half)))
        pts.append((root_r * math.cos(c + tooth_half),
                     root_r * math.sin(c + tooth_half)))

    return pts, root_r


# -- Sketch Helpers -----------------------------------------------------------

def draw_closed_polygon(sketch, pts):
    """Draw a closed polygon from a list of (x, y) tuples."""
    lines = sketch.sketchCurves.sketchLines
    p3 = adsk.core.Point3D.create
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        lines.addByTwoPoints(p3(x1, y1, 0), p3(x2, y2, 0))


def draw_circle_as_polygon(sketch, cx, cy, radius, sides=32):
    """Draw a regular polygon approximating a circle."""
    lines = sketch.sketchCurves.sketchLines
    p3 = adsk.core.Point3D.create
    for i in range(sides):
        a1 = 2.0 * math.pi * i / sides
        a2 = 2.0 * math.pi * (i + 1) / sides
        lines.addByTwoPoints(
            p3(cx + radius * math.cos(a1), cy + radius * math.sin(a1), 0),
            p3(cx + radius * math.cos(a2), cy + radius * math.sin(a2), 0)
        )


def pick_best_profile(sketch):
    """Select the gear body profile (the one with the most loops)."""
    count = sketch.profiles.count
    if count == 0:
        return None
    if count == 1:
        return sketch.profiles.item(0)

    # The gear body profile has the most loops (outer boundary + bore hole)
    best = None
    best_loops = 0
    for i in range(count):
        p = sketch.profiles.item(i)
        loops = p.profileLoops.count
        if loops > best_loops:
            best_loops = loops
            best = p
    return best


# -- Main Entry Point ---------------------------------------------------------

def run(context):
    """Main function called by Fusion 360."""
    try:
        design = adsk.fusion.Design.cast(app.activeProduct)
        if not design:
            ui.messageBox('No active Fusion 360 design.\n'
                          'Please create or open a design first.',
                          'Gear Generator')
            return

        root_comp = design.rootComponent

        # -- Collect User Input -------------------------------------------
        s, c = ui.inputBox('Gear type:\n  spur\n  helical\n  bevel\n  ring',
                           'Gear Type', 'spur')
        if c: return
        gear_type = s.strip().lower()

        s, c = ui.inputBox('Number of teeth (6 or more):', 'Teeth', '20')
        if c: return
        num_teeth = max(6, int(float(s)))

        s, c = ui.inputBox('Module in mm (tooth size, e.g. 2):', 'Module', '2')
        if c: return
        module_mm = float(s)
        module_cm = module_mm / 10.0          # Fusion internal units = cm

        s, c = ui.inputBox('Face width in mm:', 'Width', '10')
        if c: return
        width_cm = float(s) / 10.0

        bore_cm = 0.0
        if gear_type != 'ring':
            s, c = ui.inputBox('Bore diameter in mm (0 = none):', 'Bore', '5')
            if c: return
            bore_cm = float(s) / 10.0

        ring_wall_cm = 0.5                    # Default 5mm ring wall
        if gear_type == 'ring':
            s, c = ui.inputBox('Ring wall thickness in mm:', 'Ring Wall', '5')
            if c: return
            ring_wall_cm = float(s) / 10.0

        # -- Validate -----------------------------------------------------
        pitch_r = num_teeth * module_cm / 2.0
        root_r = pitch_r - 1.25 * module_cm

        if gear_type != 'ring' and root_r <= 0:
            ui.messageBox('Root radius is zero or negative.\n'
                          'Increase teeth count or module.',
                          'Gear Generator')
            return

        if bore_cm > 0 and (bore_cm / 2.0) >= root_r:
            ui.messageBox(
                f'Bore diameter ({bore_cm * 10:.1f} mm) is too large.\n'
                f'Must be less than root diameter ({root_r * 20:.1f} mm).\n'
                f'Reduce bore or increase teeth/module.',
                'Gear Generator')
            return

        # -- Build Sketch -------------------------------------------------
        sketch = root_comp.sketches.add(root_comp.xYConstructionPlane)
        sketch.name = 'GearProfile'
        sketch.isComputeDeferred = True       # Speed up bulk line creation

        if gear_type == 'ring':
            inner_pts, outer_base_r = ring_gear_outline(num_teeth, module_cm)
            outer_r = outer_base_r + ring_wall_cm
            draw_closed_polygon(sketch, inner_pts)
            draw_circle_as_polygon(sketch, 0, 0, outer_r, sides=48)
        else:
            gear_pts = spur_gear_outline(num_teeth, module_cm)
            draw_closed_polygon(sketch, gear_pts)

        # Bore hole (polygon inside gear outline)
        if bore_cm > 0:
            draw_circle_as_polygon(sketch, 0, 0, bore_cm / 2.0, sides=24)

        sketch.isComputeDeferred = False      # Finalize all geometry

        # -- Select Profile -----------------------------------------------
        profile = pick_best_profile(sketch)
        if not profile:
            ui.messageBox('No closed profile found.\nCheck your parameters.',
                          'Gear Generator')
            return

        # -- Extrude ------------------------------------------------------
        extrudes = root_comp.features.extrudeFeatures
        ext_input = extrudes.createInput(
            profile, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        ext_input.setDistanceExtent(
            False, adsk.core.ValueInput.createByReal(width_cm))

        feat = extrudes.add(ext_input)
        body = feat.bodies.item(0)
        body.name = f'{gear_type.capitalize()}Gear_{num_teeth}T_{module_mm:.0f}M'

        # -- Success Report -----------------------------------------------
        pd = num_teeth * module_mm
        td = pd + 2.0 * module_mm
        rd = pd - 2.5 * module_mm

        msg = (f'Gear Created Successfully!\n\n'
               f'Type:      {gear_type.capitalize()}\n'
               f'Teeth:     {num_teeth}\n'
               f'Module:    {module_mm} mm\n'
               f'Pitch dia: {pd:.1f} mm\n'
               f'Tip dia:   {td:.1f} mm\n'
               f'Root dia:  {rd:.1f} mm\n'
               f'Width:     {width_cm * 10:.1f} mm\n'
               f'Bore:      {bore_cm * 10:.1f} mm')

        if gear_type == 'ring':
            msg += f'\nWall:      {ring_wall_cm * 10:.1f} mm'

        ui.messageBox(msg, 'Gear Generator')

    except Exception:
        ui.messageBox(f'Error:\n{traceback.format_exc()}', 'Gear Generator - Error')
