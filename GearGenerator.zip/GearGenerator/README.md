# Fusion 360 Gear Generator v2.0

A Fusion 360 script that creates parametric gears directly in your design. Draws complete gear profiles mathematically — no circular patterns, no API headaches.

**Author:** Benjamin Morgan

---

## Supported Gear Types

| Type | Description |
|------|-------------|
| **Spur** | Standard cylindrical gears for parallel shafts |
| **Helical** | Same profile, for angled tooth engagement |
| **Bevel** | Same profile, for perpendicular shafts |
| **Ring** | Internal teeth pointing inward, with outer wall |

## How to Use

1. Open Fusion 360 and create or open a design
2. Go to **Utilities → Scripts and Add-Ins → Scripts**
3. Select **GearGenerator** and click **Run**
4. Answer the dialog prompts:

| Prompt | What it means | Example |
|--------|---------------|---------|
| Gear type | spur, helical, bevel, or ring | `spur` |
| Number of teeth | How many teeth (6+) | `20` |
| Module (mm) | Tooth size — bigger = bigger gear | `2` |
| Face width (mm) | Thickness of the gear | `10` |
| Bore diameter (mm) | Center hole size (0 = solid) | `5` |
| Ring wall (mm) | Wall thickness (ring gears only) | `5` |

5. The gear appears in your design. Done.

## Parameters Guide

**Module** controls the overall size. Two gears must have the **same module** to mesh.

| Module | Gear Size | Use Case |
|--------|-----------|----------|
| 1 | Small | Watch mechanisms, small robots |
| 2 | Medium | General purpose, 3D printing |
| 3 | Large | Power transmission, heavy duty |

**Teeth count** affects smoothness and diameter:
- Minimum: 6 (but 12+ recommended)
- More teeth = smoother, larger gear
- Pitch diameter = teeth × module

**Bore** is the center hole for a shaft. Set to 0 for a solid gear.

## Calculated Dimensions

The script automatically computes and displays:

- **Pitch diameter** = teeth × module
- **Tip diameter** = pitch + 2 × module
- **Root diameter** = pitch − 2.5 × module

## Common Gear Pairs

| Drive Gear | Driven Gear | Ratio | Notes |
|------------|-------------|-------|-------|
| 20T, M2 | 40T, M2 | 1:2 | Speed reduction |
| 15T, M2 | 15T, M2 | 1:1 | Same speed |
| 30T, M2 | 20T, M2 | 3:2 | Slight reduction |
| 12T, M3 | 36T, M3 | 1:3 | High torque |

## How It Works

Unlike typical gear scripts that create one tooth and use Fusion's circular pattern feature, this script **draws every tooth mathematically** in a single sketch:

1. Computes 7 points per tooth (root, flanks, tip) around the full circle
2. Connects them as one closed polygon
3. Adds bore hole as an inner polygon
4. Extrudes the profile to the specified width

This approach uses only basic, rock-solid Fusion API calls:
- `sketchLines.addByTwoPoints()` — draw lines
- `extrudeFeatures` — extrude the profile

No construction axes, no circular patterns, no compatibility issues.

## Files

```
GearGenerator/
├── GearGenerator.py        ← The script
├── GearGenerator.manifest  ← Fusion 360 script metadata
├── README.md               ← This file
└── ScriptIcon.svg          ← Script icon
```

## Troubleshooting

| Error | Fix |
|-------|-----|
| "No active Fusion 360 design" | Create or open a design first |
| "Root radius is zero or negative" | Use more teeth or a larger module |
| "Bore diameter too large" | Reduce bore size or increase teeth/module |
| "No closed profile found" | Parameters created an invalid shape — try defaults first |

## License

Free to use and modify.
